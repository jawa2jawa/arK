package com.ark.server;

public interface Action {

}
