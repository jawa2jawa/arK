package com.ark.server;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingDeque;

public class WebServer {
	static ConcurrentHashMap<String, Class> requesHandlersMap = new ConcurrentHashMap<String, Class>();
	static String rootLocation = "", packageStr = "", tmp = "", prePAckage = "src/main/java/";
	int len = 0;
	static Class tempClass = null;

	public static void populateHandlers(String path) {
		File location = new File(path);
		String[] allFiles = location.list();
		int len = allFiles.length, pathLen = 0;
		for (int i = 0; i < len; i++) {
			File aux = new File(path + File.separator + allFiles[i]);
			if ((path + File.separator + allFiles[i]).contains("src") && aux.isDirectory()) {
				populateHandlers(aux.getAbsolutePath());
			} else {
				pathLen = rootLocation.length();
				tmp = path + File.separator + allFiles[i];
				if (tmp.endsWith(".java")) {
					packageStr = tmp.substring(pathLen + 1);
					packageStr = packageStr.substring(prePAckage.length());
					packageStr = packageStr.replace('/', '.');
					try {
						pathLen = packageStr.length();
						packageStr = packageStr.substring(0, pathLen - 5);
						tempClass = Class.forName(packageStr);
						if (tempClass.getName().equals("com.ark.server.Action")) {
							continue;
						}
						Method[] methods = tempClass.getDeclaredMethods();
						System.out.println(methods[0].getName());
						requesHandlersMap.put(methods[0].getName(), tempClass);

					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}
		}
	}

	public static void main(String[] args) throws IOException {
		rootLocation = (new File(".")).getAbsolutePath();
		populateHandlers(".");
		LinkedBlockingDeque<Socket> requestsPool = new LinkedBlockingDeque<Socket>();
		String hamdlersPath = "/home/samuel-amar-jawahar/arkSpace/calllifoServer/src/main/java/com/ark/server/Controller.java";
		ServerSocket listenScket = new ServerSocket(6789);
		while (true) {
			String requestMessageLine;
			Socket connectionSocket = listenScket.accept();
			requestsPool.add(connectionSocket);

		}
	}
}
