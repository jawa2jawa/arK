package com.ark.server;

import java.util.HashMap;

public class UserAction implements Action {
	public HashMap<String, String> allUeser(HashMap<String, String> params) {
		return null;
	}
}
