package com.ark.server;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.concurrent.LinkedBlockingDeque;

public class RequestConsumer implements Runnable {
	LinkedBlockingDeque<Socket> requestsPool;
	Socket connectionSocket = null;

	public RequestConsumer(LinkedBlockingDeque<Socket> requestsPool) {
		// TODO Auto-generated constructor stub
		this.requestsPool = requestsPool;
	}

	public void handleRequest() throws IOException, InterruptedException {
		connectionSocket = requestsPool.take();
		BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
		DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
		String requestMessageLine = inFromClient.readLine();
		String data[] = requestMessageLine.split(" ");
		if (data[0].trim().equals("GET")) {
			// inFile.read(fileBytes);
			String result = "sa";
			byte[] fileBytes = result.getBytes();
			outToClient.writeBytes("HTTP/1.0 200 Document Follows\r\n");
			outToClient.writeBytes("Connect-Type:application/json\r=n");

			outToClient.writeBytes("Connect-Length:" + fileBytes.length + "\r\n");
			outToClient.writeBytes("\r\n");
			outToClient.write(fileBytes, 0, fileBytes.length);
			connectionSocket.close();
		} else {
			System.out.println("Bad Request Message");
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (true) {
			try {
				handleRequest();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
