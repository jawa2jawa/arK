package requesthandler;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class RequestHandler {

	public static void main(String[] args) {
		Class myClass;
		try {
			myClass = Class.forName("requesthandler.MathServices");
			Object obj = myClass.newInstance();
			MathServices d1 = (MathServices) obj;
			System.out.println("Object created and value is " + d1.welcome()); // prints 10
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void welcome() {
		Class myClass;
		try {
			PrintWriter out=new PrintWriter("C:\\workSpace\\arK\\FirstRequest.html");
			myClass = Class.forName("requesthandler.MathServices");
			Object obj = myClass.newInstance();
			MathServices d1 = (MathServices) obj;
			out.println(d1.welcome());
			out.close();
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void addNumbers() {
		Class myClass;
		try {
			PrintWriter out=new PrintWriter("C:\\workSpace\\arK\\FirstRequest.html");
			myClass = Class.forName("requesthandler.MathServices");
			Object obj = myClass.newInstance();
			MathServices d1 = (MathServices) obj;
			out.println(d1.addNumbers());
			out.close();
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
