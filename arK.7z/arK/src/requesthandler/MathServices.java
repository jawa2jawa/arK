package requesthandler;

public class MathServices {
	public String welcome() {
		return "Welcome to Math Services..";
	}
	public String addNumbers() {
		return "The Sum of 3+5="+8;
	}
}
