import requesthandler.MathServices;

public class Demo {
	int x = 10;

	public static void main(String args[])
			throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		Class myClass = Class.forName("requesthandler.MathServices");
		Object obj = myClass.newInstance();
		MathServices d1 = (MathServices) obj;
		System.out.println("Object created and value is " + d1.welcome()); // prints 10
	}
}