package arK.util;

import java.util.HashMap;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import arK.security.User;

public class ContextHandler extends DefaultHandler {
	boolean classElement = false;
	boolean methodElement = false;
	boolean userElement = false;
	boolean nameElement = false;
	boolean pwdElement = false;
	boolean privilegeElement = false;
	boolean typeElement = false;

	String className = "";
	String methodName = "";
	String logicalName = "";

	String privilege = "";
	String userName = "";
	String pwd = "";

	String name = "";
	String password = "";

	String keyStr = "";

	String type = "";

	StringBuilder argSt = new StringBuilder();
	StringBuilder paramStr = new StringBuilder();
	HashMap<String, String> urlMapper = null;
	HashMap<User, String> userTable = null;

	public ContextHandler(HashMap<String, String> urlMapper, HashMap<User, String> userTable) {
		this.urlMapper = urlMapper;
		this.userTable = userTable;
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if (qName.equalsIgnoreCase("type")) {
			typeElement = true;
		}
		if (qName.equalsIgnoreCase("name")) {
			nameElement = true;
		}
		if (qName.equalsIgnoreCase("password")) {
			pwdElement = true;
		}
		if (qName.equalsIgnoreCase("privilege")) {
			privilegeElement = true;
		}

		if (qName.equalsIgnoreCase("user")) {
			classElement = true;
		}
		if (qName.equalsIgnoreCase("class")) {
			className = attributes.getValue(0);
			classElement = true;
		}
		if (qName.equalsIgnoreCase("method")) {
			paramStr.delete(0, paramStr.length());
			methodName = attributes.getValue(0);
			logicalName = attributes.getValue(1);
			privilege = attributes.getValue(2);
			methodElement = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (qName.equalsIgnoreCase("type")) {
			userName = argSt.toString();
			nameElement = false;
		}

		if (qName.equalsIgnoreCase("name")) {
			userName = argSt.toString();
			nameElement = false;
		}
		if (qName.equalsIgnoreCase("password")) {
			pwd = argSt.toString();
			pwdElement = false;
		}
		if (qName.equalsIgnoreCase("privilege")) {
			privilege = argSt.toString().trim();
			privilegeElement = false;
		}

		if (qName.equalsIgnoreCase("class")) {
			classElement = false;
		}
		if (qName.equalsIgnoreCase("user")) {
			User usr = new User(userName, pwd);
			userTable.put(usr, privilege);
			userElement = false;
		}
		if (qName.equalsIgnoreCase("method")) {
			System.out.println("class=" + className + "#method=" + methodName + "#args=" + paramStr.toString());
			urlMapper.put(logicalName, className + "#" + methodName + "#"
					+ paramStr.toString().substring(0, paramStr.toString().length() - 1) + "#" + privilege);
			methodElement = false;
			paramStr.delete(0, paramStr.length());
		}
		argSt.delete(0, argSt.length());
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {
		String value = "";
		if (methodElement) {
			value = new String(ch, start, length);
			if (value.trim().length() == 0) {
				return;
			}
			paramStr.append(value.trim()).append(":");
			return;
		}
	}
}
