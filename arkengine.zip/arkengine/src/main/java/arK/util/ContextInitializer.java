package arK.util;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import arK.security.User;

public class ContextInitializer {
	public static HashMap<String, Class> classPool = new HashMap<String, Class>();
	public static HashMap<String, Service> requestServiceMap = new HashMap<String, Service>();
	public static HashMap<User, String> userPrivilegeMap = new HashMap<User, String>();
	public static HashMap<User, String> sessionTable = new HashMap<User, String>();
	public static User currentUser=null;

	public ContextInitializer() {
		HashMap<String, String> contextMap = new HashMap<String, String>();
		try {
			File inputFile = new File("src/main/resources/context.xml");
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser saxParser = factory.newSAXParser();
			ContextHandler userhandler = new ContextHandler(contextMap,userPrivilegeMap);
			saxParser.parse(inputFile, userhandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			requestServiceMap = populateMethodPool(contextMap);
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new ContextInitializer();
	}

	public static HashMap<String, Service> populateMethodPool(HashMap<String, String> contextMapper)
			throws InvocationTargetException, InstantiationException {
		HashMap<String, Service> actionMapper = new HashMap<String, Service>();
		String className = "";
		String methodName = "";
		String args = "";
		String privilege="";
		Set set = contextMapper.keySet();
		String value = "", key = "", data[] = null;
		Iterator iterator = set.iterator();
		while (iterator.hasNext()) {
			key = (String) iterator.next();
			value = contextMapper.get(key);
			data = value.split("#");

			className = data[0];
			methodName = data[1];
			args = data[2];
			privilege=data[3];
			Class cl;
			try {
				cl = Class.forName(className);
				cl = classPool.get(className);
				if (cl == null) {
					cl = Class.forName(className);
					classPool.put(className, cl);
				}
				Method m[] = cl.getDeclaredMethods();
				int len = m.length, size = 0, j = 0;
				boolean match = true;
				Method calledMethod = null;
				for (int i = 0; i < len; i++) {
					if (methodName.equals(m[i].getName())) {
						calledMethod = m[i];
						Class types[] = calledMethod.getParameterTypes();
						data = args.split(":");
						if (types.length == data.length) {
							match = true;
							size = data.length;
							for (j = 0; j < size; j++) {
								if (!types[j].toString().contains(data[j])) {
									match = false;
									break;
								}
							}
							if (match) {
								calledMethod = m[i];
								Service service = new Service(cl, m[i], types,privilege);
								if(!key.startsWith("/")) {
									key="/"+key;
								}
								actionMapper.put(key, service);
							}
						}
					}

				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return actionMapper;
	}

}
