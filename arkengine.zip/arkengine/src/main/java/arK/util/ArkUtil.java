package arK.util;

import arK.server.Argument;
import arK.server.ServiceManager;

public class ArkUtil {
	public static String logicalName="";
	static String data[]=null;
	public static void loadParameters(String request) {
		int firstIndex = request.indexOf("?");
		if (firstIndex == -1) {
			return;
		}
		logicalName=request.substring(0, firstIndex);
		logicalName=logicalName.split(" ")[1];
		if(!logicalName.startsWith("/")) {
			logicalName="/"+logicalName;
		}
		ServiceManager.service=ContextMapper.actionMapper.get(logicalName);
		int lastIndex = request.indexOf("HTTP");
		request = request.substring(firstIndex + 1, lastIndex);
		String tokes[] = request.split("&");
		int len = tokes.length;
		String data[] = new String[2];
		for (int i = 0; i < len; i++) {
			data = tokes[i].split("=");
			ServiceManager.params.put(new Argument(data[0]), data[1]);
		}
	}

	public static String getMethodType(String request) {
		String tokens[] = request.split("/");
		return tokens[0].trim();
	}

	public static String getApplicationContextName(String request) {
		String tokens[] = request.split("/");
		return tokens[1].trim();
	}
}