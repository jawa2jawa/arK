package arK.util;

import arK.server.Argument;
import arK.server.ServiceManager;

public class ArkUtil {
	public static String logicalName="";
	static String data[]=null;
	public static void loadGetParameters(String request) {
		int firstIndex = request.indexOf("?");
		if (firstIndex == -1) {
			return;
		}
		
		int lastIndex = request.indexOf("HTTP");
		request = request.substring(firstIndex + 1, lastIndex);
		String tokes[] = request.split("&");
		int len = tokes.length;
		String data[] = new String[2];
		for (int i = 0; i < len; i++) {
			data = tokes[i].split("=");
			ServiceManager.params.put(new Argument(data[0]), data[1]);
		}
	}
	
	public static void loadPostParameters(String request) {
		request=request.substring(1).trim();
		
		String tokes[] = request.split(",");
		int len = tokes.length;
		String data[] = new String[2];
		for (int i = 0; i < len; i++) {
			data = tokes[i].split(":");
			ServiceManager.params.put(new Argument(data[0]), data[1]);
		}
	}

	public static String getMethodType(String request) {
		String tokens[] = request.split(" ");
		logicalName=tokens[1].trim();
		if(!logicalName.startsWith("/")) {
			logicalName="/"+logicalName;
		}
		ServiceManager.service=ContextManager.requestServiceMap.get(logicalName);
		return tokens[0].trim();
	}

	public static String getApplicationContextName(String request) {
		String tokens[] = request.split("/");
		return tokens[1].trim();
	}
}