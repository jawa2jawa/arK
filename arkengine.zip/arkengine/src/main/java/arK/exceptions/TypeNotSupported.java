package arK.exceptions;

public class TypeNotSupported extends RuntimeException {
	public TypeNotSupported() {
		super();
	}

	public String toString() {
		return "Type Not expected change to String";
	}
}
