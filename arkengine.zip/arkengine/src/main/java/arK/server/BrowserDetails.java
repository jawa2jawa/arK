package arK.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;

public class BrowserDetails {
	private static HashMap<String, String> browserMap = new HashMap<String, String>();

	public static void populateBrowserDetails(BufferedReader inFromClient) {
		try {
			String nextLine = "";
			String data[] = null;
			while (!(nextLine = inFromClient.readLine()).startsWith("Accept-Language")) {
				data = nextLine.split(":");
				browserMap.put(data[0], data[1]);
			}
			data = nextLine.split(":");
			browserMap.put(data[0], data[1]);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String getProperty(String key) {
		return browserMap.get(key);
	}
}
