package arK.server;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.net.InetAddress;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import arK.util.ArkUtil;

public class RequestHandler {
	String contentType = "";
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
	LocalDateTime now = LocalDateTime.now();
	ConnectionDetails connectionDetails = null;

	public RequestHandler() {
		connectionDetails = new ConnectionDetails();
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public void auditUser(Socket connectionSocket) {
		InetAddress addr = connectionSocket.getInetAddress();
		System.out.println("Connection made to " + addr.getHostName() + " (" + addr.getHostAddress() + ")");
	}

	public void processRequest(Socket connectionSocket) throws IOException {
		auditUser(connectionSocket);
		String requestMessageLine;
		BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()), 512);
		requestMessageLine = inFromClient.readLine();
		 connectionDetails.populateBrowserDetails(inFromClient);
		DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
		if (requestMessageLine == null) {
			outToClient.close();

			return;
		}

		if (ArkUtil.getMethodType(requestMessageLine).equals("GET")) {
			doGet(outToClient, requestMessageLine);
		}
		if (ArkUtil.getMethodType(requestMessageLine).equals("POST")) {
			doPost(outToClient, requestMessageLine);
		}
		connectionSocket.close();
	}

	public void doGet(DataOutputStream outToClient, String requestMessageLine) {

		String methodStr = requestMessageLine.split(" ")[1].trim();
		if (methodStr.contains("favicon")) {
			contentType = "Connect-Type:image/png\r\n";
			prepareFavIcon(outToClient);
		} else if (methodStr.length() > 1) {
			if (methodStr.contains("index.htm")) {
				prepareDeafultPage(outToClient);
			} else {
				ServiceManager.params.clear();
				ArkUtil.loadParameters(requestMessageLine);
				invokeMethod(outToClient);
			}
		} else {
			prepareDeafultPage(outToClient);
		}
	}

	public void doPost(DataOutputStream outToClient, String requestMessageLine) {

		String methodStr = requestMessageLine.split(" ")[1].trim();
		if (methodStr.contains("favicon")) {
			contentType = "Connect-Type:image/png\r\n";
			prepareFavIcon(outToClient);
		} else if (methodStr.length() > 1) {
			if (methodStr.contains("index.htm")) {
				prepareDeafultPage(outToClient);
			} else {
				ServiceManager.params.clear();
				ArkUtil.loadParameters(requestMessageLine);
				invokeMethod(outToClient);
			}
		} else {
			prepareDeafultPage(outToClient);
		}
	}

	public void prepareBadResponse(DataOutputStream outToClient) {
		try {
			ClassLoader classLoader = this.getClass().getClassLoader();
			File file = new File(classLoader.getResource("BadRequest.html").getFile());
			int numOfBytes = (int) file.length();
			FileInputStream inFile = new FileInputStream(file);
			byte[] fileBytes = new byte[numOfBytes];
			inFile.read(fileBytes);
			outToClient.writeBytes("HTTP/1.0 200 Document Follows\r\n");
			outToClient.writeBytes("Connect-Length:" + numOfBytes + "\r\n");
			outToClient.writeBytes("\r\n");
			outToClient.write(fileBytes, 0, numOfBytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				outToClient.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return;

	}

	public void prepareFavIcon(DataOutputStream outToClient) {

		try {
			ClassLoader classLoader = this.getClass().getClassLoader();
			File file = new File(classLoader.getResource("favicon.ico").getFile());
			int numOfBytes = (int) file.length();
			FileInputStream inFile = new FileInputStream(file);
			byte[] fileBytes = new byte[numOfBytes];
			inFile.read(fileBytes);
			outToClient.writeBytes("HTTP/1.0 200 Document Follows\r\n");
			if (contentType.trim().length() > 0) {
				// outToClient.writeBytes(contentType.trim());
			}
			outToClient.writeBytes("Connect-Length:" + numOfBytes + "\r\n");
			outToClient.writeBytes("\r\n");
			outToClient.write(fileBytes, 0, numOfBytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				outToClient.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public void invokeMethod(DataOutputStream outToClient) {
		try {

			byte[] fileBytes = ServiceManager.executeMethod().getBytes();
			int numOfBytes = fileBytes.length;
			outToClient.writeBytes("HTTP/1.0 200 Document Follows\r\n");
			outToClient.writeBytes("Connect-Length:" + numOfBytes + "\r\n");
			outToClient.writeBytes("\r\n");
			outToClient.write(fileBytes, 0, numOfBytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				outToClient.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public void prepareDeafultPage(DataOutputStream outToClient) {
		try {
			ClassLoader classLoader = this.getClass().getClassLoader();
			File file = new File(classLoader.getResource("index.html").getFile());
			int numOfBytes = (int) file.length();
			FileInputStream inFile = new FileInputStream(file);
			byte[] fileBytes = new byte[numOfBytes];
			inFile.read(fileBytes);
			outToClient.writeBytes("HTTP/1.0 200 Document Follows\r\n");
			outToClient.writeBytes("Date: " + dtf.format(now) + "\r\n");
			outToClient.writeBytes("Server: ArkServer\r\\n");
			Cookie.addCookie("sessionID", "537");
			outToClient.writeBytes("Set-Cookie: " + Cookie.cookies + "\r\\n");
			outToClient.writeBytes("Connection: close \r\\n");
			if (contentType.trim().length() > 0) {
				outToClient.writeBytes(contentType.trim());
			}
			outToClient.writeBytes("Connect-Length:" + numOfBytes + "\r\n");
			outToClient.writeBytes("\r\n");
			outToClient.write(fileBytes, 0, numOfBytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				outToClient.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void prepareLoginPage(DataOutputStream outToClient) {
		try {
			ClassLoader classLoader = this.getClass().getClassLoader();
			File file = new File(classLoader.getResource("login.html").getFile());
			int numOfBytes = (int) file.length();
			FileInputStream inFile = new FileInputStream(file);
			byte[] fileBytes = new byte[numOfBytes];
			inFile.read(fileBytes);
			outToClient.writeBytes("HTTP/1.0 200 Document Follows\r\n");
			outToClient.writeBytes("Date: " + dtf.format(now) + "\r\n");
			outToClient.writeBytes("Server: ArkServer\r\\n");
			Cookie.addCookie("sessionID", "537");
			outToClient.writeBytes("Set-Cookie: " + Cookie.cookies + "\r\\n");
			outToClient.writeBytes("Connection: close \r\\n");
			if (contentType.trim().length() > 0) {
				outToClient.writeBytes(contentType.trim());
			}
			outToClient.writeBytes("Connect-Length:" + numOfBytes + "\r\n");
			outToClient.writeBytes("\r\n");
			outToClient.write(fileBytes, 0, numOfBytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				outToClient.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
