package arK.server;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.HashMap;

import arK.exceptions.TypeNotSupported;
import arK.util.Service;

public class ServiceManager {
	public static HashMap<Argument, String> params = new HashMap<Argument, String>();
	public static String result = "";
	public static Service service = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

	public static void putParam(String key, String value) {
		params.put(new Argument(key), value);
	}

	/**
	 * It works on the reflection get the package ,class, method and
	 * arguments,signature of the method it store the key method signature and the
	 * result in hashmap It maintains the math that contains the class name and
	 * class Object
	 */
	public static String executeMethod() throws InvocationTargetException, InstantiationException {

		try {
			return invokeMethod(service.getMethod(), service.getInvoker().newInstance());
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

	public static String invokeMethod(Method calledMethod, Object instance) {
		Class types[] = calledMethod.getParameterTypes();
		Parameter args[] = calledMethod.getParameters();
		Parameter p = null;
		int len = types.length;
		String name = "";
		Object methodParameters[] = new Object[calledMethod.getParameterCount()];
		for (int i = 0; i < len; i++) {
			p = args[i];
			if (p.isNamePresent()) {
				System.out.println(p.getName() + "---" + params.get(new Argument(p.getName())));
				if (types[i] == int.class || types[i] == Integer.class) {
					methodParameters[i] = Integer.parseInt(params.get(new Argument(p.getName())));
					continue;
				}
				if (types[i] == float.class || types[i] == Float.class) {
					methodParameters[i] = Float.parseFloat(params.get(new Argument(p.getName())));
					continue;
				}
				if (types[i] == byte.class) {
					methodParameters[i] = Byte.parseByte(params.get(new Argument(p.getName())));
					continue;
				}
				if (types[i] == boolean.class) {
					methodParameters[i] = Boolean.parseBoolean(params.get(new Argument(p.getName())));
					continue;
				}
				if (types[i] == long.class || types[i] == Long.class) {
					methodParameters[i] = Long.parseLong(params.get(new Argument(p.getName())));
					continue;
				}
				if (types[i] == double.class || types[i] == Double.class) {
					methodParameters[i] = Double.parseDouble(params.get(new Argument(p.getName())));
					continue;
				}
				if (types[i] == String.class) {
					methodParameters[i] = params.get(new Argument(p.getName()));
					continue;
				}
				throw new TypeNotSupported();

			}
		}
		try {
			Object retVal = calledMethod.invoke(instance, methodParameters);
			return retVal.toString();
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
}
