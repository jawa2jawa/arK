package arK.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;

public class ConnectionDetails {
	private HashMap<String, String> browserDetailsMap = new HashMap<String, String>();

	public HashMap<String, String> getBrowserDetailsMap() {
		return browserDetailsMap;
	}

	public void setBrowserDetailsMap(HashMap<String, String> browserDetailsMap) {
		this.browserDetailsMap = browserDetailsMap;
	}

	public void populateBrowserDetails(BufferedReader inFromClient) {
		try {
			String nextLine = "";
			String data[] = null;
			while ((nextLine = inFromClient.readLine()) != null) {
				System.out.println(nextLine);
				if (nextLine.indexOf(':') != -1) {
					data = nextLine.split(":");
					getBrowserDetailsMap().put(data[0], data[1]);
				} else {
					break;
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getProperty(String key) {
		return browserDetailsMap.get(key);
	}
}
