package arK.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;

public class ConnectionDetails {
	private HashMap<String, String> browserDetailsMap = new HashMap<String, String>();
	int contentLen=0;
	String body="";
	public String getBody() {
		return body;
	}

	public HashMap<String, String> getBrowserDetailsMap() {
		return browserDetailsMap;
	}

	public void setBrowserDetailsMap(HashMap<String, String> browserDetailsMap) {
		this.browserDetailsMap = browserDetailsMap;
	}

	public void populateBrowserDetails(BufferedReader inFromClient) {
		try {
			String nextLine = "";
			String data[] = null;
			boolean contentStarts=false;
			StringBuilder params=new StringBuilder();
			int len=0;
			while ((nextLine = inFromClient.readLine()) != null) {
				System.out.println(nextLine);
				if(contentStarts) {
					params.append(nextLine);
					len+=nextLine.getBytes().length;
					if(contentLen==len+5) {
						body=params.toString();
						break;
					}
					continue;
				}
				if (nextLine.indexOf(':') != -1) {
					data = nextLine.split(":");
					getBrowserDetailsMap().put(data[0], data[1]);
					if(data[0].contains("Content-Length")){
						contentLen=Integer.parseInt(data[1].trim());
					}
				} 
				if(nextLine.trim().length()==0) {
					if(contentLen==0) {
						break;
					}
					len+=nextLine.getBytes().length;
					contentStarts=true;
				}
				 
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getProperty(String key) {
		return browserDetailsMap.get(key);
	}
}
