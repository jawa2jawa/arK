package arK.server;

public class Argument {

	public Argument(String arg) {
		if(arg.trim().startsWith("\"")) {
			arg=arg.trim().substring(1);
		}
		if(arg.trim().endsWith("\"")) {
			arg=arg.trim().substring(0,arg.trim().length()-1);
		}
		this.arg = arg;
	}

	public String getArg() {
		return arg;
	}

	public void setArg(String arg) {
		this.arg = arg;
	}

	public Class getType() {
		return type;
	}

	public void setType(Class type) {
		this.type = type;
	}

	public boolean equals(Object obj) {
		String pram =  ((Argument)obj).getArg();
		return arg.equalsIgnoreCase(pram);
	}

	public int hashCode() {
		return arg.toLowerCase().hashCode();
	}

	String arg = "";
	Class type = null;
}
