package arK.server;

import java.io.IOException;
import java.net.Socket;

public class RequestThread implements Runnable {
	RequestHandler requestHandler = null;
	Socket connectionSocket = null;

	public RequestThread(RequestHandler requestHandler, Socket connectionSocket) {
		this.requestHandler = requestHandler;
		this.connectionSocket = connectionSocket;
	}

	public void run() {
		// TODO Auto-generated method stub
		try {
			connectionSocket.setSoTimeout(10000);
			requestHandler.processRequest(connectionSocket);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
