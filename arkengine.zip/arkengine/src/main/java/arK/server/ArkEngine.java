package arK.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import arK.util.ContextMapper;

public class ArkEngine {

	public static void main(String[] args) throws IOException {
		ContextMapper contextMapper=new ContextMapper();
		ServerSocket listenScket = new ServerSocket(6789);
		ExecutorService executor = Executors.newFixedThreadPool(50);
		while (true) {
			executor.execute(new RequestRunner(new RequestHandler(), listenScket.accept()));
		}
	}

}