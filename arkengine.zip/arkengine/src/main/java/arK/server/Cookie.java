package arK.server;

import java.util.HashMap;
import java.util.Iterator;

public class Cookie {
	static HashMap<String, String> cookiesMap = new HashMap<String, String>();
	static String cookies = "";

	public static void addCookie(String key, String value) {
		cookiesMap.put(key, value);
	}

	public static String getValue(String key) {
		return cookiesMap.get(key);
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		String key = "";
		Iterator iterator = cookiesMap.keySet().iterator();
		while (iterator.hasNext()) {
			key = (String) iterator.next();
			sb.append(key).append("=").append(cookiesMap.get(key));
		}
		cookies=sb.toString().substring(0, sb.toString().length() - 1);
		return cookies;
	}
}
