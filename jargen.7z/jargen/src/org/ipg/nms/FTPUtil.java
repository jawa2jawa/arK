package org.ipg.nms;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.ipg.util.MathUtil;

public class FTPUtil {
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
	LocalDateTime now = LocalDateTime.now();

	public String uploadFile() {
		System.out.println("It is from file uploading..");
		return "Hello It is Ark on " + dtf.format(now);
	}

	public String porcessData(String firstname, String lastname) {
		System.out.println("It is from file uploading..");
		MathUtil mu=new MathUtil();
		return "Hello " + firstname + ":" + lastname + " It is Ark on " + dtf.format(now)+" sum="+mu.showSum(5, 6);
	}

}
