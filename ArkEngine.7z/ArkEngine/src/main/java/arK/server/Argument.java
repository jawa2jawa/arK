package arK.server;

public class Argument {

	public Argument(String arg) {
		this.arg = arg;
	}

	public String getArg() {
		return arg;
	}

	public void setArg(String arg) {
		this.arg = arg;
	}

	public Class getType() {
		return type;
	}

	public void setType(Class type) {
		this.type = type;
	}

	public boolean equals(Object obj) {
		String pram =  ((Argument)obj).getArg();
		return arg.equalsIgnoreCase(pram);
	}

	public int hashCode() {
		return arg.toLowerCase().hashCode();
	}

	String arg = "";
	Class type = null;
}
