package arK.util;

import java.lang.reflect.Method;

public class Service {
	public Service(Class invoker, Method method, Class types[]) {
		this.invoker = invoker;
		this.method = method;
		this.types = types;
	}

	Class invoker = null;
	Method method = null;
	Class types[] = null;

	public Class[] getTypes() {
		return types;
	}

	public void setTypes(Class[] types) {
		this.types = types;
	}

	public Class getInvoker() {
		return invoker;
	}

	public void setInvoker(Class invoker) {
		this.invoker = invoker;
	}

	public Method getMethod() {
		return method;
	}

	public void setMethod(Method method) {
		this.method = method;
	}
}
