package arK.util;

import java.util.HashMap;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ContextHandler extends DefaultHandler {
	boolean classElement = false;
	boolean methodElement = false;
	String className = "";
	String methodName = "";
	String logicalName = "";
	String keyStr = "";
	StringBuilder argSt = new StringBuilder();
	HashMap<String, String> urlMapper =null;

	public ContextHandler(HashMap<String, String> urlMapper) {
		this.urlMapper = urlMapper;
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if (qName.equalsIgnoreCase("class")) {
			className = attributes.getValue(0);
			classElement = true;
		}
		if (qName.equalsIgnoreCase("method")) {
			methodName = attributes.getValue(0);
			logicalName = attributes.getValue(1);
			methodElement = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (qName.equalsIgnoreCase("class")) {
			classElement = false;
		}
		if (qName.equalsIgnoreCase("method")) {
			System.out.println("class="+className + "#method=" + methodName + "#args=" + argSt.toString() );
			urlMapper.put(logicalName, className + "#" + methodName + "#" + argSt.toString().substring(0, argSt.toString().length()-1));
			methodElement = false;
			argSt.delete(0, argSt.length());
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {
		if (methodElement) {
			String value = new String(ch, start, length);
			if (value.trim().length() == 0) {
				return;
			}
			argSt.append(value).append(":");

		}

	}
}
